# filter  
# By: losmust
# https://Instagram/losmust404
# https://github.com/losmust

import os
from colorama import Fore, Style
def welcome_message():
    welcome = """
⢻⣤⣾⢟⣵⣾⣿⣿⣿⣿⣿⣷⣤⡀⠤⣝⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿ 
⣿⣿⢣⣾⣿⣿⣿⠻⣿⣿⣧⡝⣿⣿⡮⢙⣷⣝⠻⣿⢻⣿⣿⣿⣿⣿⣿ code: losmust
⣿⡇⣾⡿⣿⣿⣿⣷⡙⠿⣿⣿⣮⢻⣿⡆⢿⣿⣆⠒⢾⣿⣿⣿⣿⣿⣿ 
⣿⢰⣿⣧⢻⣿⣿⣿⠧⢫⡶⠂⣬⣅⢻⡿⡈⣯⢞⡂⠑⣼⣿⣿⣿⣿⣿ 
⠿⢸⣿⣿⣮⠻⡿⣿⡓⠄⠺⢾⣿⣿⠸⣡⡇⣿⠃⠃⢸⣿⣿⣿⣿⣿⣿ 
⣦⡌⡇⠻⣿⡰⡎⣀⣰⣶⣾⣿⣿⡿⣰⣿⠇⠸⡀⣶⣼⣿⣿⣿⣿⣿⣿ 
⣿⣿⢀⢇⡡⠳⡑⠻⣿⢟⣥⣶⠆⠁⣿⠏⠄⣰⣇⣿⣿⣿⣿⣿⣿⣿⣿ 
⣿⠋⠈⢸⣽⣷⠈⠄⢠⣾⠫⢄⣠⢸⡏⣼⠮⠭⣉⣩⣭⣶⣭⣟⢿⣿⣿ 
⣿⣀⠄⢸⢇⡵⢊⣴⣿⡏⣶⣶⣮⡸⡠⣵⣾⣿⣿⣿⣿⣿⣿⣿⣷⡙⢿ 
⣿⡿⢂⡴⣫⣶⣿⣿⠿⣸⣿⣿⣿⣷⣤⣿⣿⣿⣿⣿⣿⣿⡜⣿⣿⣿⣎ 
⡫⢞⣭⣾⣿⣿⢟⣵⣿⣿⣿⣿⣿⣯⢻⣿⣿⣿⣿⣿⣿⣿⣿⣮⠻⡿⢛ 
⣾⣿⣿⣿⠟⣱⣿⣿⣿⣿⣿⣿⣿⣿⡆⢿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡍⢰ 
⣿⣿⠟⣫⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⢹⣿⣿⡜ 
⢛⠁⢰⣿⢸⣿⣿⣙⣿⣿⣿⣿⣿⣿⣿⢠⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃ 
⣿⣗⠂⣿⣇⢻⣿⣿⣿⣿⣿⣿⣿⡿⣣⣿⣷⣍⡻⢿⣿⣿⣿⡿⠟⠁⣾ 
⣿⣿⡄⢻⡿⠷⠝⡛⠿⠿⢿⣛⣭⣾⣿⣿⣿⣿⣿⣿⣶⣶⣶⣾⠄⢰⣿ 
⣿⣿⣿⣶⣶⣶⣦⡀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣣⣿⡘⣿

private logs:
t.me/freelogsclouds01
  
    """
    print(f"{Fore.MAGENTA}{welcome}")

def main():
    os.system('clear' if os.name == 'posix' else 'cls')  

    welcome_message()
  
    (f"{Fore.MAGENTA}")     

    
    
    print("Digite o nome do txt:")
    nome_arquivo = input()
    
    print(" ")
    print("Digite a palavra de busca:")
    palavra_LM = input()

    with open(nome_arquivo, 'r') as arquivo_teste:
        quantidade_linhas = sum(1 for _ in arquivo_teste if palavra_LM in _)

    arquivo_saida = f"[{quantidade_linhas}]_{palavra_LM}.txt"

    try:
        with open(nome_arquivo, 'r') as arquivo_entrada, open(arquivo_saida, 'w') as arquivo_saida:
            linhas_encontradas = 0

            for linha in arquivo_entrada:
                if palavra_LM in linha:
                    linha_completa = linha.strip() + " t.me/freelogsclouds01 \n"
                    arquivo_saida.write(linha_completa)
                    linhas_encontradas += 1

            print(f"\nForam encontrado {linhas_encontradas} logins.")

    except FileNotFoundError:
        print(f"{Fore.RED}Erro: ERROR.{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Erro: {e}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()